import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;
import java.util.Scanner;
import java.util.Set;
import java.util.HashSet;

public class Controller {

    @FXML
    private TextArea taOutput;

    public void initialize() {

        final String JDBC_DRIVER = "org.h2.Driver";
        final String DB_URL = "jdbc:h2:./resources/BicycleDB";

        //  Database credentials
        final String USER = "";
        final String PASS = "";
        Connection conn = null;
        Statement stmt = null;

        try {
            // STEP 1: Register JDBC driver
            Class.forName(JDBC_DRIVER);
            //Class.forName(new org.h2.Driver());

            //STEP 2: Open a connection
            //conn = DriverManager.getConnection(DB_URL, USER, PASS);
            conn = DriverManager.getConnection(DB_URL);

            //STEP 3: Execute a query
            stmt = conn.createStatement();

            String sql = "SELECT * FROM Bike";

            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                taOutput.appendText(rs.getString(1) + "\n");
            }

            // STEP 4: Clean-up environment
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            taOutput.appendText(e.toString());
        } catch (ClassNotFoundException e) {
            taOutput.appendText(e.toString());
        }
    }
}


public class CollegeDegreeAuditWithDatabase {

    public static void main(String[] args) {
        // Initialize the H2 database connection
        try {
            Connection connection = DriverManager.getConnection("jdbc:h2:mem:test;DB_CLOSE_DELAY=-1", "sa", "");
            Statement statement = connection.createStatement();

            // Create a table to store course information
            statement.execute("CREATE TABLE IF NOT EXISTS courses (" +
                    "courseCode VARCHAR(10) PRIMARY KEY, " +
                    "courseName VARCHAR(255), " +
                    "major VARCHAR(50))");

            // Insert sample data into the courses table
            statement.execute("INSERT INTO courses VALUES ('CS101', 'Introduction to Computer Science', 'Computer Science')");
            statement.execute("INSERT INTO courses VALUES ('MATH101', 'Calculus I', 'Mathematics')");
            statement.execute("INSERT INTO courses VALUES ('ENG101', 'English Composition', 'English')");
            // Add more courses...

            // Prompt the user to enter their major path
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter your major: ");
            String userMajor = scanner.nextLine();

            // Create a set to store the required courses for the user's major
            Set<String> requiredCourses = new HashSet<>();

            // Query the database to find required courses for the user's major
            ResultSet resultSet = statement.executeQuery("SELECT courseCode, courseName FROM courses WHERE major = '" + userMajor + "'");
            while (resultSet.next()) {
                String courseCode = resultSet.getString("courseCode");
                String courseName = resultSet.getString("courseName");
                requiredCourses.add(courseCode + " - " + courseName);
            }

            // Generate a degree audit report
            System.out.println("Degree Audit for " + userMajor + " Major:");
            for (String course : requiredCourses) {
                System.out.println(course);
            }

            // Close resources
            resultSet.close();
            statement.close();
            connection.close();
            scanner.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
