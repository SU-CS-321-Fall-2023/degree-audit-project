import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

class Module
{
    private final char name;

    Module(final char name)
    {
        this.name = name;
    }

    @Override
    public boolean equals(final Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        final Module module = (Module) o;
        return name == module.name;
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(name);
    }

    @Override
    public String toString()
    {
        return "Module " + name;
    }
}

class TimeSlot
{
    private final int id;
    private final List<Module> modules = new ArrayList<>();

    TimeSlot(final int id)
    {
        this.id = id;
    }

    void addModule(final Module module)
    {
        modules.add(module);
    }

    boolean containsAny(final List<Module> modules)
    {
        return modules.stream().anyMatch(this.modules::contains);
    }

    @Override
    public String toString()
    {
        return "Time-Slot{modules=" + modules + ", id=" + id + '}';
    }
}

class Student
{
    private final String name;
    private final List<Module> modules;

    Student(final String name, final List<Module> modules)
    {
        this.name = name;
        this.modules = modules;
    }

    List<Module> getModules()
    {
        return modules;
    }

    @Override
    public String toString()
    {
        return name;
    }
}

public class Main
{
    public static void main(final String... args)
    {
        System.out.println(calculateSchedule(data()));
    }

    private static List<Student> data()
    {
        return Arrays.asList(
                new Student("Sydney",  Arrays.asList(new Module('A'), new Module('G'), new Module('F'), new Module('C'))),
                new Student("Maddy",   Arrays.asList(new Module('E'), new Module('F'), new Module('B'), new Module('A'))),
                new Student("Peyton", Arrays.asList(new Module('D'), new Module('A'), new Module('G'), new Module('E')))
        );
    }

    private static String calculateSchedule(final List<Student> students)
    {
        final List<TimeSlot> slots = new ArrayList<>();
        final Map<Module, List<Student>> modulesToStudentsByPopularity = sortLargestFirst(
                modulesToStudents(students)
        );
        for (final Map.Entry<Module, List<Student>> entry : modulesToStudentsByPopularity.entrySet())
        {
            final Module module = entry.getKey();
            final List<Student> modulesStudents = entry.getValue();
            boolean isSlotAvailable = false;
            for (final TimeSlot slot : slots)
            {
                isSlotAvailable = isSlotAvailable(slot, modulesStudents);
                if (isSlotAvailable)
                {
                    slot.addModule(module);
                    break;
                }
            }
            if (!isSlotAvailable)
            {
                final TimeSlot newSlot = new TimeSlot(slots.size());
                newSlot.addModule(module);
                slots.add(newSlot);
            }
        }
        return slots.toString();
    }

    private static Map<Module, List<Student>> modulesToStudents(final List<Student> students)
    {
        final Map<Module, List<Student>> modulesToStudents = new HashMap<>();
        for (final Student student : students)
        {
            for (final Module module : student.getModules())
            {
                modulesToStudents.putIfAbsent(module, new ArrayList<>());
                modulesToStudents.get(module).add(student);
            }
        }
        return modulesToStudents;
    }

    private static <K, V> Map<K, List<V>> sortLargestFirst(final Map<K, List<V>> input)
    {
        return input.entrySet().stream()
                .sorted((a, b) -> b.getValue().size() - a.getValue().size()) // Sort by size, descending
                .collect(
                        Collectors.toMap(
                                Map.Entry::getKey,
                                Map.Entry::getValue,
                                (a, b) -> { throw new AssertionError(); },
                                LinkedHashMap::new
                        )
                );
    }

    private static boolean isSlotAvailable(final TimeSlot slot, final List<Student> students)
    {
        return students.stream().noneMatch(student -> slot.containsAny(student.getModules()));
    }
}